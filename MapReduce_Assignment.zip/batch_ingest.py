import happybase

# create connection
connection = happybase.Connection('localhost', port=9090, autoconnect=False)

# get table pointer
def get_tbl(name):
    connection.open()
    tbl = connection.table(name)
    connection.close()
    return tbl

# insert the data in the intervals of 100k
def insert_data(file_nm, tbl_nm):
    print("starting batch insert of {}".format(file_nm))

    file = open(file_nm, 'r')

    tbl = get_tbl(tbl_nm)
    connection.open()
    i = 0
    with tbl.batch(batch_size=100000) as b:
        for line in file:
            if i!=0:
                row = line.strip().split(",")
                b.put(row[1]+row[2] ,{'cf1:VendorID': str(row[0]), 'cf1:tpep_pickup_datetime': str(row[1]), 'cf1:tpep_dropoff_datetime': str(row[2]), 'cf1:passenger_count': str(row[3]), 'cf1:trip_distance': str(row[4]), 'cf1:RatecodeID': str(row[5]), 'cf1:store_and_fwd_flag': str(row[6]), 'cf1:PULocationID': str(row[7]), 'cf1:DOLocationID': str(row[8]), 'cf1:payment_type': str(row[9]),'cf1:fare_amount': str(row[10]), 'cf1:extra': str(row[11]), 'cf1:mta_tax': str(row[12]), 'cf1:tip_amount': str(row[13]), 'cf1:tolls_amount': str(row[14]), 'cf1:improvement_surcharge': str(row[15]), 'cf1:total_amount': str(row[16]), 'cf1:congestion_surcharge': str(row[17]), 'cf1:airport_fee': str(row[18]) })
            i+=1

    file.close()

    print("batch insert done")
    connection.close()



insert_data('yellow_tripdata_2017-03.csv', 'trip_dtl_hbase')
insert_data('yellow_tripdata_2017-04.csv', 'trip_dtl_hbase')